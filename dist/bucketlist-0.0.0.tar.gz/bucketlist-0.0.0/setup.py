from setuptools import setup

setup(
    name='bucketlist',
    version='',
    packages=['app', 'instance'],
    url='',
    license='',
    author='ubuntu-1804',
    author_email='skg31297@gmail.com',
    description='Python Distribution Utilities'
)
